SEAS OF MAYHEM - PROJETO ANDROID + COMPILACAO NA NUVEM

Este pacote inclui o editor HTML dentro de um app Android (WebView) e um workflow do GitHub Actions para tentar gerar o APK sem precisar de computador. O APK NAO vem pronto dentro deste ZIP: ele sera gerado pelo GitHub depois de enviares os arquivos e iniciares a compilacao.

COMO GERAR O APK SO PELO CELULAR
1. Entra em https://github.com/ e cria uma conta ou inicia sessao. Se a plataforma pedir idade ou autorizacao, segue as regras dela e pede ajuda a um responsavel quando necessario.
2. Cria um repositorio novo, por exemplo SeasOfMayhemAndroid. Pode ser privado.
3. Extrai este ZIP no celular usando o gerenciador de arquivos. Envia o CONTEUDO da pasta SeasOfMayhemAndroid para o repositorio, mantendo a estrutura de pastas. O arquivo .github/workflows/build-apk.yml precisa estar presente. Se o gerenciador esconder pastas que comecam com ponto, confirma que a pasta .github tambem foi enviada.
4. Depois de enviar os arquivos, abre a aba Actions do repositorio.
5. Seleciona "Gerar APK Android". Se aparecer "Run workflow", toca nele e confirma.
6. Espera a compilacao terminar. Se ficar verde, abre a execucao e procura a secao Artifacts.
7. Baixa o artefato "SeasOfMayhem-APK.zip", extrai e instala o arquivo app-debug.apk no Android. O Android pode pedir autorizacao para instalar apps desta origem.

SE DER ERRO
- Abre a execucao em Actions e olha o primeiro passo vermelho. A mensagem de erro pode ser copiada aqui para eu ajudar a corrigir.
- A compilacao na nuvem depende do GitHub Actions estar disponivel para o repositorio/conta.
- Este e um APK de debug para instalacao pessoal, nao um pacote pronto para publicar na Play Store.

DETALHES
- O editor HTML esta em app/src/main/assets/index.html.
- A biblioteca usa localStorage do app e nao sincroniza automaticamente com outros dispositivos.
- Importacao de backups JSON esta habilitada.
- Exportacao de backup via URL blob pode precisar de ajuste especifico para WebView.
- O projeto e o workflow foram preparados, mas a compilacao ainda precisa ser executada no GitHub para confirmar que gera corretamente.
